    </main><!-- /.container -->

    <br><br><br><br>

    <footer>
      Atividade Final de Tecnologias Web - Prof. Me. Joseph Soares Alcântara
      <address>
        <img class="imgs_peq" src="<?=base_url('static/imagens/mail.png')?>" alt="E-mail:">
        <a href="mailto:atendimento@PizzaDelicia.com">atendimento@PizzaDelicia.com</a>
        <img class="imgs_peq" src="<?=base_url('static/imagens/wpp.png')?>" alt="Wpp:">
        <a href="https://api.whatsapp.com/send?phone=88996695833" target="_blank">(88) 9-9669-5833</a>
      </address>
      <p>
        <small>Pizza Delícia &copy; <?=date('Y')?> - Todos os direitos reservados.</small>
      </p>
    </footer>

    <!-- jQuery, Popper.js, Bootstrap JS, Custom Script -->
    <script type="text/javascript" src="<?=base_url('static/js/jquery-3.3.1.min.js')?>"></script>
    <script type="text/javascript" src="<?=base_url('static/js/popper.min.js')?>"></script>
    <script type="text/javascript" src="<?=base_url('static/js/bootstrap.min.js')?>"></script>
    <script type="text/javascript" src="<?=base_url('static/js/jquery.mask.min.js')?>"></script>
    <script type="text/javascript" src="<?=base_url('static/js/code.js')?>"></script>

  </body>

</html>
