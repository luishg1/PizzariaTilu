    </main><!-- /.container -->

    <!-- jQuery, Popper.js, Bootstrap JS, Custom Script -->
    <script type="text/javascript" src="<?=base_url('static/js/jquery-3.3.1.min.js')?>"></script>
    <script type="text/javascript" src="<?=base_url('static/js/popper.min.js')?>"></script>
    <script type="text/javascript" src="<?=base_url('static/js/bootstrap.min.js')?>"></script>
    <script type="text/javascript" src="<?=base_url('static/js/jquery.mask.min.js')?>"></script>
    <script type="text/javascript" src="<?=base_url('static/js/code.js')?>"></script>

  </body>

</html>
