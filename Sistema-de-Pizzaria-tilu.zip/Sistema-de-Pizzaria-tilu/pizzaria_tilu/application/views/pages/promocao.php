<div class="container-fluid">
	<h1 id="promo" class="img-fluid"	>#Super Hyper Mega Promo!!!</h1><br>

<div class="row">
	<div class="col-sm-2">

	</div>
	<div class="col-sm-2">
		<img id="gif3" class="img-fluid" src="<?=base_url('static/imagens/pisca.gif')?>">
	</div>
	<div class="col-sm">
		<br>
		<h2 id="promo1">Toda TERÇA e QUINTA!</h2>
	</div>

</div>


	<br><br><br>
	<div class="row">
  	<div class="col-sm"><img class="img-fluid" src="<?=base_url('static/imagens/calabresa1.png')?>"></div>
  	<div class="col-sm"><img class="img-fluid"  src="<?=base_url('static/imagens/catupiry1.png')?>"></div>
  	<div class="col-sm"><img  class="img-fluid"  src="<?=base_url('static/imagens/carneseca1.png')?>"></div>
	</div>




</div>
