<div class="container">
  <div class="row">
    <div class="col-sm-1"></div>
    <div class="col-sm-10">
      <section>
        <figure class="slider">
          <img class="foto" src="<?=base_url('static/imagens/imgs/001.jpg')?>">
          <img class="foto" src="<?=base_url('static/imagens/imgs/002.jpg')?>">
          <img class="foto" src="<?=base_url('static/imagens/imgs/003.jpg')?>">
          <img class="foto" src="<?=base_url('static/imagens/imgs/004.jpg')?>">
          <img class="foto" src="<?=base_url('static/imagens/imgs/005.jpg')?>">
          <img class="foto" src="<?=base_url('static/imagens/imgs/006.jpg')?>">
        </figure>
      </section>
    </div>
    <div class="col-sm-1"></div>
  </div>
</div>

      <img id="gif" class = "img-fluid" src="<?=base_url('static/imagens/giphy.gif')?>">

      <br><br>

      <h3 class="al">
	      &emsp;&emsp;"Nós da Pizza Delícia estamos muito felizes em lhe atender.
        Estamos no ramo de pizzaria a mais de 25 anos, sempre com a missão de satisfazer
        nossos clientes. Levando até você o prazer de saborear a mais deliciosa pizza do
        Ceará. Aqui você pode <a href="<?=site_url('pedido')?>">Realizar Pedido</a>,
        ficar antenado no nosso <a href="<?=site_url('cardapio')?>">Cardápio</a> e
        nossas <a href="<?=site_url('promocao')?>">Promoções</a>, além de sempre
        nos dar <a href="<?=site_url('sugestao')?>">Sugestões</a> de melhoria,
        para sempre crescer junto com você na arte de fazer pizza".
      </h3>

      <br><br><br><br>

      <h1 class="al" id="al">Ângela, Lucas, Tadeu, Kamila e Hugo</h1>
